
from PIL import Image
class Texture:
	"is Image holder. communicates with Material"
	def __init__(self):
		self.image = Image
	def bind(self):#channel?
		1

