from window import Window
window = Window()
window.set_title('engine!')


from shader import Shader
vertn = """
#version 410 core
layout (location = 0) in vec3 position;
//layout (location = 1) in vec3 color;
out vec3 out_color;

uniform mat4 Model;
//uniform mat4 View;
//uniform mat4 Projection;
uniform mat4 ProjectionView;

uniform vec3 color;

uniform float time;

void main() 
{
    //gl_Position = ViewProjection * Model * vec4(pos, 1);
    
    //gl_Position = vec4(position, 1);
    //gl_Position = Projection * View * Model * vec4(position, 1);
    //gl_Position = ProjectionView * Model * vec4(position, 1);
    //gl_Position = vec4(position, 1);
    
    vec3 new_position = position;
    new_position.y *= time;

    gl_Position = ProjectionView * Model * vec4(new_position, 1);
    
    //out_color = vec3(1,0,1);
    out_color = color;
}

"""
shader = Shader(vertn)




from vao import Vao
#data = {'position':[0,0,0,   1,0,0, 1,1,1 ,0,1,0] ,'index':[0,1,2, 0,2,3] ,'color': [1,0,0, 0,1,0, 0,0,1, 1,0,1] }
#vao = Vao(data)
vao = Vao()




from camera import Camera
cam = Camera()





keymap = {
	'ESCAPE_':lambda:window.close(),
	#'MOUSE_M':'set_cursor_lock',
	'MOUSE_R': lambda:window.set_cursor_lock(True),

	'W':lambda:cam.set_speed(1),
	'S':lambda:cam.set_speed(-1),
	'W_':lambda:cam.set_speed(0),
	'S_':lambda:cam.set_speed(0),
	
	'F':lambda:make_unit(),
}

#need value for axis input..
inputmap = {
	'MOUSE_DXDY': lambda v:cam.set_dxdy(*v) ,
	'D': lambda v:cam.set_dxdy(0.1,0) ,
	'A': lambda v:cam.set_dxdy(-0.1,0) ,
}


def inputfunc(inputs):
	for i in inputs:
		name,value = i
		func = inputmap.get(name, lambda x:1)
		func(value)
		#print(cam.front, cam.yaw)



from unit import Unit

import random
units = []
def make_unit():
	unit = Unit()
	unit.transform.racc.set(0,10,0) #x->y->z order.
	
	x,y,z = random.randint(-5,5) , random.random(), random.randint(-5,3)
	unit.transform.pos.set(x,y,z)
	unit.transform.acc.set(0,y,0)


	unit.uniforms['color'] = random.random(),random.random(),random.random()
	units.append(unit)

[make_unit() for i in range(100)]

def update(dt):
	cam.update(dt)
	for unit in units:
		unit.update(dt)
		if unit.transform.pos.y>15:
			unit.transform.pos.y = -2

import time

t = time.time()

def draw():
	shader.bind()
	
	ProjectionView = cam.get_ProjectionView()
	shader.set_mat4('ProjectionView', (ProjectionView).to_list() )

	for unit in units:
		Model = unit.get_Model()
		shader.set_mat4('Model', Model.to_list() )
		shader.set_vec3('color', unit.uniforms['color'] )

		shader.set_vec3('color', unit.uniforms['color'] )
		
		shader.set_float('time', time.time()-t )

		vao.bind()
		vao.draw(0)
		vao.draw(2)


window.bind_keymap(keymap)
window.bind_input(inputfunc)
window.bind_update(update)
window.bind_draw(draw)
window.glPointSize(5)


window.run()
