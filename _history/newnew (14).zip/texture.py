import numpy as np
from PIL import Image

class Texture:
	"is Image holder. communicates with Material"
	def __init__(self):
		self.image = Image
	def bind(self):#channel?
		1



# glEnable(GL_TEXTURE_2D)
# glBindTexture(tex.target, tex.id)#tex.target= created 'texture' in gpu
# glDisable(tex.target)    




