from math import sqrt , acos, sin,cos, atan2, asin , radians, tan

#operations. not vector nor quat but useful.
def dot(x1,y1,z1, x2,y2,z2):
    return x1*x2 + y1*y2 + z1*z2
def cross(ax,ay,az, bx,by,bz):
    #xyzzy
    cx = ay*bz-az*by
    cy = az*bx-ax*bz
    cz = ax*by-ay*bx
    return cx,cy,cz
def normalize(x,y,z):
    mag = sqrt(x**2+y**2+z**2)
    if mag == 0:
        return 0,0,0
    return x/mag, y/mag, z/mag

def mag(x,y,z):
    "is norm, also."
    return sqrt(x**2+y**2+z**2)
def mag2(x,y,z):
    return x**2+y**2+z**2


def angle(a,b,c,  d,e,f):
    "between vecs."
    #costh = _dot(a,b,c, d,e,f) / ( _mag(a,b,c) * _mag(d,e,f) )
    costh = (a*d + b*e + c*f) / sqrt( (a**2+b**2+c**2)*(d**2+e**2+f**2)  )
    return acos(costh)
