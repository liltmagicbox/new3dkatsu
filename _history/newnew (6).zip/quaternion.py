from vecops import *

desc = """
x,y,z,w
radians

"""

#https://math.stackexchange.com/questions/40164/how-do-you-rotate-a-vector-by-a-unit-quaternion
def quat_angleaxis(angle,axis):
    #https://danceswithcode.net/engineeringnotes/quaternions/quaternions.html
    #"axis should be normalized.. since x*[0-1.0].."
    axis = normalize(*axis)

    #x,y,z = axis *sin(th/2) #vector
    w = cos(angle/2)  # scalar

    sin_th2 = sin(angle/2)
    ax,ay,az = axis
    x = ax*sin_th2
    y = ay * sin_th2
    z = az * sin_th2
    return x,y,z,w

def quat_to_matrix(quat):
    """col-major. downward.
    https://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation"""
    x,y,z,w = quat
    mat = (
    1 - 2*y**2 - 2*z**2,  2*x*y + 2*z*w,  2*x*z - 2*y*w, 0,
    2*x*y - 2*z*w,  1 - 2*x**2 - 2*z**2,  2*y*z + 2*x*w, 0,
    2*x*z + 2*y*w,  2*y*z - 2*x*w,  1 - 2*x**2 - 2*y**2, 0,
    0,0,0,1
    )
    return mat

#use front- cross-method. axis angle
#def quat_look(quat, target):



def quat_to_angleaxis(quat):
    """
    https://danceswithcode.net/engineeringnotes/quaternions/quaternions.html
    It is worth noting that there are several ways to conv..
    """
    x,y,z,w = quat

    angle = 2*acos(w)

    sin_th2 = sin(angle/2)
    if sin_th2 <0.001:#0.06deg
        return 0, 1,0,0
    ax = x/sin_th2
    ay = y/sin_th2
    az = z/sin_th2
    return angle, ax,ay,az


#=== with euler
def quat_euler(xyz):
    #https://en.wikipedia.org/wiki/Conversion_between_quaternions_and_Euler_angles
    #Euler angles to quaternion conversion
    x,y,z = xyz
    cy = cos(z/2)
    sy = sin(z/2)
    cp = cos(y/2)
    sp = sin(y/2)
    cr = cos(x/2)
    sr = sin(x/2)

    x = sr * cp * cy - cr * sp * sy
    y = cr * sp * cy + sr * cp * sy
    z = cr * cp * sy - sr * sp * cy
    w = cr * cp * cy + sr * sp * sy
    return x,y,z,w


def quat_rotate_xyz(quat, xyz):
    """
    rotate position x,y,z
    returns not normalized. #1.5-8x faster than qpq way.
    https://en.wikipedia.org/wiki/Conversion_between_quaternions_and_Euler_angles
    
    history is below,there were times v*v -> v.
    v + qw*tv +qv*tv
    rx = x + qw*tx +qx*tx
    ry = y + qw*ty +qy*ty
    rz = z + qw*tz +qz*tz
    """

    qx,qy,qz,qw = quat
    x,y,z = xyz
    #qhat requires normlized?
    # mag = sqrt(qw**2+ qx**2+ qy**2+ qz**2)
    # qw /= mag
    # qx /= mag
    # qy /= mag
    # qz /= mag

    # v=xyz  v'= rotated xyz
    # quat ->  qw, qv
    # t = 2* (q X v)
    # v' = v + qw*t + (qv X t)
    
    #tx,ty,tz = _cross(qx,qy,qz, x,y,z)
    #tx *=2
    #ty *=2
    #tz *=2
    #cross acts like this..
    tx,ty,tz = cross(qx*2,qy*2,qz*2, x,y,z)
    
    ctx,cty,ctz = cross(qx,qy,qz, tx,ty,tz)
    rx = x + qw*tx + ctx
    ry = y + qw*ty + cty
    rz = z + qw*tz + ctz
    return rx,ry,rz


def quat_to_direction(quat):
    return quat_rotate_xyz(quat, (1,0,0) )



def _rotation_test():
    x = quat_to_direction( (0,0,0,1) )
    print(x)

    quat = quat_angleaxis( 0.1, (0,0,1) )
    x = quat_to_direction( quat )
    print(x)

    quat = quat_angleaxis( 1.57, (0,0,1) )
    x = quat_to_direction( quat )
    print(x)

    quat = quat_angleaxis( -1.57, (0,0,1) )
    x = quat_to_direction( quat )
    print(x)



if __name__ == '__main__':
    #main()
    _rotation_test()









def _quat_to_rotmat(w,x,y,z):
    """rows x0->x1
    https://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation"""
    r0 = 1 - 2*y**2 - 2*z**2
    r1 = 2*x*y - 2*z*w
    r2 = 2*x*z + 2*y*w
    r3 =  0    
    r4 = 2*x*y + 2*z*w
    r5 = 1 - 2*x**2 - 2*z**2
    r6 = 2*y*z - 2*x*w
    r7 = 0
    r8 = 2*x*z - 2*y*w
    r9 = 2*y*z + 2*x*w
    r10 = 1 - 2*x**2 - 2*y**2
    r11 = 0
    
    r12 = 0
    r13 = 0
    r14 = 0
    r15 = 1
    return (r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15)

