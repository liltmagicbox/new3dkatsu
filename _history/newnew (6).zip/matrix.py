from vecops import *
from quaternion import *


desc = """
not using Quat/Vec3, but functions. for functional.

tuple, better.

"""

def dot4(A,B):
    A0,A1,A2,A3 = A
    B0,B1,B2,B3 = B
    return A0*B0 + A1*B1 + A2*B2 + A3*B3

def mul4x4(A,B):
    "extreamly ineff."
    A,B = B,A #for glm.mat4x4.
    a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15 = A
    b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15 = B
    
    row0 = a0,a1,a2,a3
    row1 = a4,a5,a6,a7
    row2 = a8,a9,a10,a11
    row3 = a12,a13,a14,a15
    
    col0 = b0,b4,b8,b12
    col1 = b1,b5,b9,b13
    col2 = b2,b6,b10,b14
    col3 = b3,b7,b11,b15

    mat = (
    dot4(row0,col0), dot4(row0,col1), dot4(row0,col2), dot4(row0,col3), 
    dot4(row1,col0), dot4(row1,col1), dot4(row1,col2), dot4(row1,col3), 
    dot4(row2,col0), dot4(row2,col1), dot4(row2,col2), dot4(row2,col3), 
    dot4(row3,col0), dot4(row3,col1), dot4(row3,col2), dot4(row3,col3), )
    return mat








#==============================
def gl_ortho(left, right, bottom, top, near,far):
    a = right - left
    b = top - bottom
    c = far - near
    mat = ( 
        2/a, 0,0,0,
        0, 2/b, 0,0,
        0,0, -2/c, 0,0,
        -(right+left)/a, -(top+bottom)/b, -(far+near)/c ,1.0
        )
    return mat

def gl_perspective(fov, ratio, near, far):
    "fov=radians, perspective list is platten col-major mat."
    f = 1/tan(fov/2)
    mat = ( f/ratio, 0, 0, 0,
      0,   f,  0, 0, 
      0,   0,  (far+near)/(near-far), -1,
      0,  0,   (2*far*near)/(near-far),  0)
    return mat


def gl_lookAt(eye,target,up):
    """
    https://www.khronos.org/opengl/wiki/GluLookAt_code
    https://registry.khronos.org/OpenGL-Refpages/gl2.1/xhtml/gluLookAt.xml
    side: both lh,rh same.
    """
    tx,ty,tz = target
    ex,ey,ez = eye

    forward = tx-ex, ty-ey, tz-ez
    forward = normalize(*forward)
    side = cross(*forward, *up)
    side = normalize(*side)
    up = cross(*side, *forward)
    up = normalize(*up)
    
    fx,fy,fz = forward
    sx,sy,sz = side
    ux,uy,uz = up

    #https://registry.khronos.org/OpenGL-Refpages/gl2.1/xhtml/gluLookAt.xml
    # v1 = (
    # sx,ux,-fx,0,
    # sy,uy,-fy,0,
    # sz,uz,-fz,0,
    # 0,0,0,1)
    # v2 = (1,0,0,0, 0,1,0,0, 0,0,1,0, -ex,-ey,-ez,1)
    # return mul4x4(v1,v2)

    #px,py,pz = eye.dot(side), eye.dot(up), eye.dot(forward)#simulates M1*M2..
    #px,py,pz = -eye.dot(side), -eye.dot(up), eye.dot(forward)#not right, side-effected.
    #why -,-,+?
    px = -dot(*eye,*side)
    py = -dot(*eye,*up)
    pz = dot(*eye,*forward)
    mixed = (
    sx,ux,-fx,0,
    sy,uy,-fy,0,
    sz,uz,-fz,0,
    px,py,pz, 1.0
    )
    return mixed



def gl_translate(xyz):
    x,y,z = xyz
    return (1,0,0,0, 0,1,0,0, 0,0,1,0, x,y,z,1)

def gl_scale(xyz):
    x,y,z = xyz
    return (x,0,0,0, 0,y,0,0, 0,0,z,0, 0,0,0,1)

def gl_rotate(angle, axis):
    quat = quat_angleaxis(angle,axis)
    return quat_to_matrix(quat)


#=======================================================

class Matrix:
    def __init__(self, *args):
        if len(args) == 0:
            data = (0.0,0.0,0.0,0.0, 0.0,0.0,0.0,0.0, 0.0,0.0,0.0,0.0, 0.0,0.0,0.0,0.0)
        elif len(args) == 16:
            data = args
        else:
            raise ValueError('Matrix requires 16s!')
        self.data = data
    def __repr__(self):
        return str(self.data)

    def __imul__(self, other):
        self.data = mul4x4(self.data, other.data)
    def __mul__(self, other):
        mat = Matrix()
        mat.data = mul4x4(self.data, other.data)
        return mat

    def to_list(self):
        return list(self.data)
    def to_tuple(self):
        return tuple(self.data)

    @classmethod
    def Perspective(cls, fov,ratio,near,far):
        return cls(*gl_perspective(fov,ratio,near,far))
    @classmethod
    def Ortho(cls, left, right, bottom, top, near, far):
        return cls(*gl_ortho(left, right, bottom, top, near, far))
    @classmethod
    def View(cls, eye, forward, up):
        return cls(*gl_lookAt(eye,forward,up))

    @classmethod
    def Translate(cls, xyz):
        return cls(*gl_translate(xyz) )
    @classmethod
    def Scale(cls, xyz):
        return cls(*gl_scale(xyz) )
    @classmethod
    def Rotate(cls, angle,axis):
        return cls(*gl_rotate(angle,axis) )
    
    @classmethod
    def translate(cls, matrix, xyz):
        t = gl_translate(xyz)
        data = mul4x4(matrix.data, t)
        return cls( *data )

        # T = cls.Translate(xyz)
        # return matrix * T

        # x,y,z = xyz
        # data = matrix.to_list()
        # data[12] += x
        # data[13] += y
        # data[14] += z
        # return cls(*data)
    @classmethod
    def scale(cls, matrix, xyz):
        s = gl_scale(xyz)
        data = mul4x4(matrix.data, s)
        return cls( *data )

        # S = cls.Scale(xyz)
        # return matrix * S

        #since first M meets, fine.
        # x,y,z = xyz
        # data = matrix.to_list()
        # data[0] *= x
        # data[5] *= y
        # data[10] *= z
        # return cls(*data)
    @classmethod
    def rotate(cls, matrix, angle,axis):
        r = gl_rotate(angle,axis)
        data = mul4x4(matrix.data, r)
        return cls( *data )

        # R = cls.Rotate(angle,axis)
        # return matrix * R

    @classmethod
    def Model(cls, pos, quat, scale):
        "input quat, faster."
        #M = cls.translate(M, pos)
        #M = cls.rotate(M, )
        #M = cls.scale(M, scale)
        
        #20000s took 1 seconds.
        #T = cls.Translate(pos)
        #R = cls.Rotate(quat)
        #S = cls.Scale(scale)
        #M = T*R*S
        #return M
        
        #.84 to .60
        # M = R*S
        # M.data[12],M.data[13],M.data[14] = pos
        # return M

        #.60 to .50
        r = quat_to_matrix(quat)
        s = gl_scale(scale)
        m = mul4x4(r,s)
        m = list(m)
        m[12],m[13],m[14] = pos
        return cls(*m)
        #40000 to 1seconds, 400 to 10ms, acceptable.



#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
#================================================================== test
def _operator_test():
    import glm
    x= glm.dot( glm.vec3(1,2,3) , glm.vec3(6,7,8))
    print(x)
    x= glm.dot( glm.vec3(6,7,8) , glm.vec3(1,2,3))
    print(x)
    x = dot( 1,2,3, 6,7,8)
    print(x)
    x = dot( 6,7,8,1,2,3)
    print(x)

    x= glm.cross( glm.vec3(1,2,3) , glm.vec3(6,7,8))
    print(x)
    x= glm.cross( glm.vec3(6,7,8) , glm.vec3(1,2,3))
    print(x)
    x = cross( 1,2,3, 6,7,8)
    print(x)
    x = cross( 6,7,8,1,2,3)
    print(x)

    x= glm.normalize( glm.vec3(1,2,3))
    print(x)
    x= glm.normalize( glm.vec3(6,7,8) )
    print(x)
    x = normalize( 1,2,3)
    print(x)
    x = normalize( 6,7,8)
    print(x)

    #[[1.0, 2.0, 3.0, 4.0], [4.0, 3.0, 2.0, 1.0], [1.0, 3.0, 2.0, 4.0], [1.0, 1.0, 2.0, 3.0]]
    x = glm.mat4x4(1,2,3,4,5,6,7,8, 1,2,3,4, 1,2,3,4)
    print(x.to_list())
    y = glm.mat4x4(9,8,7,6,5,4,3,2, 4,3,2,1, 4,3,2,1)
    print( (x*y).to_list() )

    x = Matrix(1,2,3,4,5,6,7,8, 1,2,3,4, 1,2,3,4)
    print(x)
    y = Matrix(9,8,7,6,5,4,3,2, 4,3,2,1, 4,3,2,1)
    print(x*y)

    #col major, Projection View Model Position.
    r = Matrix(2,4,6,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    t = Matrix(1,0,0,0, 0,1,0,0, 0,0,1,0, 1,2,3,1)
    print(t)
    print(t*r)
    #...glm is T R S




def _glmat_test():
    #=== projection test
    import glm
    print( glm.perspective(radians(40), 1.96,0.1,200).to_list() )
    x = gl_perspective( radians(40) , 1.96, 0.1, 200)
    print(x)

    print('-=--ortho---')

    print( glm.ortho( 0,1,0,1,0,1 ).to_list() )
    x = gl_ortho( 0,1,0,1,0,1 )
    print(x)
    print( glm.ortho( 1,3,5,7,9,2 ).to_list() )
    x = gl_ortho( 1,3,5,7,9,2 )
    print(x)


    #=== vp test
    import glm
    #finally!!!!!
    Projection = glm.perspective( 1, 1.96,0.1,200)
    View = glm.lookAt( glm.vec3(1,3,4),glm.vec3(0,0,0), glm.vec3(0,1,0))
    #print((Projection).to_list())
    #print((View).to_list())
    print((Projection*View).to_list())

    Projection = Matrix.Perspective( 1, 1.96,0.1,200)
    View = Matrix.View( (1,3,4),(0,0,0), (0,1,0))
    #print((Projection).to_list())
    #print((View).to_list())
    print((Projection*View).to_list())



    T = glm.translate( glm.vec3(1,2,3) )
    print(T.to_list())
    T = gl_translate( (1,2,3) )
    print(T)
    T = Matrix.Translate( (1,2,3) )
    print(T.to_list())


    #=== T R S each test
    import glm
    M = glm.mat4x4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    M = glm.translate(M, glm.vec3(10,100,1000))
    print(M.to_list())

    M = glm.mat4x4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    T = glm.translate(glm.vec3(10,100,1000))
    print( (M*T).to_list())

    M = Matrix(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    M = Matrix.translate(M, (10,100,1000))
    print(M.to_list())


    M = glm.mat4x4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    M = glm.scale(M, glm.vec3(10,100,1000))
    print(M.to_list())

    M = glm.mat4x4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    S = glm.scale(glm.vec3(10,100,1000))
    print( (M*S).to_list())

    M = Matrix(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    M = Matrix.scale(M, (10,100,1000))
    print(M.to_list())


    R = glm.rotate( 0.1, glm.vec3(0,0,1) )
    R = glm.rotate( 0.1, glm.vec3(1,2,3) )
    print(R.to_list())

    R = gl_rotate( 0.1, (0,0,1) )
    R = gl_rotate( 0.1, (1,2,3) )
    print(R)


    #=== TRS test
    #glm is stacking. so last one is recent.
    import glm
    M = glm.mat4x4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    M = glm.translate(M, glm.vec3(11,22,33))
    M = glm.rotate(M, 0.1, glm.vec3(1,2,3))
    M = glm.scale(M, glm.vec3(10,100,1000))
    print(M.to_list())

    M = Matrix(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    M = Matrix.translate(M, (11,22,33))
    M = Matrix.rotate(M, 0.1, (1,2,3))
    M = Matrix.scale(M, (10,100,1000))
    print(M.to_list())

    #while multiplying,, works as expected.
    M = Matrix(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    T = Matrix.Translate((11,22,33))
    R = Matrix.Rotate(0.1, (1,2,3))
    S = Matrix.Scale((10,100,1000))
    M = T*R*S*M
    print(M.to_list())


    quat = quat_angleaxis( 0.1, (0,0,1) )
    M = Matrix.Model( (11,22,33), quat, (100,100,100))
    print(M)





def glmvstimetest():
    import time
    tt=time.time

    t=tt()
    import glm

    for i in range(200000):
        M = glm.mat4x4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
        M = glm.translate(M, glm.vec3(11,22,33))
        M = glm.rotate(M, 0.1, glm.vec3(1,2,3))
        M = glm.scale(M, glm.vec3(10,100,1000))
    print(M.to_list())
    print(tt()-t)

    t=tt()
    for i in range(20000):
        quat = quat_angleaxis( 0.1, (1,2,3) )
        M = Matrix.Model( (11,22,33), quat, (10,100,1000))
    print(M.to_list())
    print(tt()-t)

    #200 -> 1ms
    #20 -> 1ms

    M = Matrix(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
    M = Matrix.translate(M, (11,22,33))
    M = Matrix.rotate(M, 0.1, (1,2,3))
    M = Matrix.scale(M, (10,100,1000))
    print(M.to_list())

if __name__ == '__main__':
    glmvstimetest()
    #main()






#===========================================================technical
#===========================================================technical
#===========================================================technical
#===========================================================technical
#===========================================================technical
#===========================================================technical
#===========================================================technical
#===========================================================technical
#===========================================================technical
def _mul4x4(A,B):
    "for easy understanding"
    A,B = B,A #for glm.mat4x4.
    a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15 = A
    b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15 = B
    
    row0 = a0,a1,a2,a3
    row1 = a4,a5,a6,a7
    row2 = a8,a9,a10,a11
    row3 = a12,a13,a14,a15
    
    col0 = b0,b4,b8,b12
    col1 = b1,b5,b9,b13
    col2 = b2,b6,b10,b14
    col3 = b3,b7,b11,b15

    m0 = dot4(row0,col0)
    m1 = dot4(row0,col1)
    m2 = dot4(row0,col2)
    m3 = dot4(row0,col3)
    
    m4 = dot4(row1,col0)
    m5 = dot4(row1,col1)
    m6 = dot4(row1,col2)
    m7 = dot4(row1,col3)
    
    m8 = dot4(row2,col0)
    m9 = dot4(row2,col1)
    m10 = dot4(row2,col2)
    m11 = dot4(row2,col3)
    
    m12 = dot4(row3,col0)
    m13 = dot4(row3,col1)
    m14 = dot4(row3,col2)
    m15 = dot4(row3,col3)
    return (m0,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15)




def _gllookat(eye,center,up):
    """
    https://www.khronos.org/opengl/wiki/GluLookAt_code
    https://registry.khronos.org/OpenGL-Refpages/gl2.1/xhtml/gluLookAt.xml
    """
    #forawrd = center-eye
    forward = (center-eye).normalize()    
    side = forward.cross(up).normalize()# lh,rh, both fine. thats why side..
    up = side.cross(forward).normalize()
    
    sx,sy,sz = side
    ux,uy,uz = up
    fx,fy,fz = forward
    ex,ey,ez = eye
    #px,py,pz = eye.dot(side), eye.dot(up), eye.dot(forward)#simulates M1*M2
    px,py,pz = -eye.dot(side), -eye.dot(up), eye.dot(forward)#not right, side-effected.
    
    mixed = [
    sx,ux,-fx,0,
    sy,uy,-fy,0,
    sz,uz,-fz,0,
    px,py,pz, 1.0
    ]
    return mixed

