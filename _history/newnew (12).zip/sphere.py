from math import cos,sin,radians

#basic 2d shape.
def shape_ring(slice=8):
	shape = []
	for i in range(slice+1):
		th = radians( 360/slice*i )
		x,y = cos(th),sin(th)
		shape.append( (x,y) )
	return shape


def make_floor(shape, height, radius=1.0, zup=False):
	floor = []
	for x,y in shape:
		x,y = x*radius, y*radius
		if zup:
			point = (x, y, height)
		else:
			point = (x, height, -y)
		floor.append(point)
	return floor

def make_floors(shape,stack=4, radius=1.0, zup=False):
	floors = []
	for height in range(stack):
		floor = make_floor(shape,height, radius,zup)
		floors.append(floor)
	return floors

x = shape_ring()
x = make_floor(x,0)

def flatten(data):
	if type(data[0]) in (int,float):
		return data
	else:
		temp = []
		for i in data:
			temp.extend(i)
		return flatten(temp)
	#print(flatten( [[[1]],[[2]],[[3]]] ))


def make_sphere():
	make_ring()