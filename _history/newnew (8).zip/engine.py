from window import Window
window = Window()
window.set_title('engine!')


from shader import Shader
vertn = """
#version 410 core
layout (location = 0) in vec3 position;
layout (location = 1) in vec3 color;
out vec3 out_color;

uniform mat4 Model;
//uniform mat4 View;
//uniform mat4 Projection;
uniform mat4 ProjectionView;

void main() 
{
    //gl_Position = ViewProjection * Model * vec4(pos, 1);
    
    //gl_Position = vec4(position, 1);
    //gl_Position = Projection * View * Model * vec4(position, 1);
    //gl_Position = ProjectionView * Model * vec4(position, 1);
    //gl_Position = vec4(position, 1);
    gl_Position = ProjectionView * Model * vec4(position, 1);
    out_color = vec3(1,0,1);
}

"""
shader = Shader(vertn)




from vao import Vao
#data = {'position':[0,0,0,   1,0,0, 1,1,1 ,0,1,0] ,'index':[0,1,2, 0,2,3] ,'color': [1,0,0, 0,1,0, 0,0,1, 1,0,1] }
#vao = Vao(data)
vao = Vao()




from camera import Camera
cam = Camera()





keymap = {
	'ESCAPE_':lambda:window.close(),
	#'MOUSE_M':'set_cursor_lock',
	'MOUSE_R': lambda:window.set_cursor_lock(True),

	'W':lambda:cam.set_speed(1),
	'S':lambda:cam.set_speed(-1),
	'W_':lambda:cam.set_speed(0),
	'S_':lambda:cam.set_speed(0),
}

#need value for axis input..
inputmap = {
	'MOUSE_DXDY': lambda v:cam.set_dxdy(*v) ,
	'D': lambda v:cam.set_dxdy(0.1,0) ,
	'A': lambda v:cam.set_dxdy(-0.1,0) ,
}


def inputfunc(inputs):
	for i in inputs:
		name,value = i
		func = inputmap.get(name, lambda x:1)
		func(value)
		#print(cam.front, cam.yaw)



from unit import Unit
unit = Unit()
unit.transform.racc.set(0,0,1)
#roll pitch yaw
#xaxis:roll yaaxis:yaw zaxis:pitch

def update(dt):
	cam.update(dt)
	unit.update(dt)

def draw():
	shader.bind()
	
	ProjectionView = cam.get_ProjectionView()
	shader.set_mat4('ProjectionView', (ProjectionView).to_list() )

	Model = unit.get_Model()
	shader.set_mat4('Model', Model.to_list() )

	vao.bind()
	vao.draw(3)


window.bind_keymap(keymap)
window.bind_input(inputfunc)
window.bind_update(update)
window.bind_draw(draw)
window.glPointSize(5)


window.run()
