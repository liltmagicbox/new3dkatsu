#from world import world
#world = World()


from window import Window
window = Window()
window.set_title('moving_rect_by_vao_update')

keymap = {
	'ESCAPE_':lambda:window.close(),
	#'MOUSE_M':'set_cursor_lock',
	'MOUSE_M': lambda:window.set_cursor_lock(True),
	'A': lambda:print('hohox'),
	'A_': lambda:print('0000000000'),

	'C':lambda:world.create(),
}



from vao import Vao,default

data = {'position':[0,0,0,   1,0,0, 1,1,1 ,0,1,0] ,'index':[0,1,2, 0,2,3]} # ,'color': [1,0,0, 0,1,0, 0,0,1, 1,0,1] 
vao = Vao(data)


import numpy as np
arr = np.array( [0,0,0,   1,0,0, 1,1,1 ,0,1,0] ,dtype='float32')

def update(dt):
	global arr
	arr -= dt # dt*hz = 1seconds. so the rect hidden after 2 seconds.
	if arr[0]<-1:
		arr+=dt
	vao.update('position',arr)
window.bind_update(update)

def draw():
	1#world.draw()
	vao.bind()
	vao.draw(3)
window.bind_draw(draw)

window.bind_keymap(keymap)

window.run()
