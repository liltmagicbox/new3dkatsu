from window import Window

window = Window()
window.set_title('hashaha')

keymap = {
	'ESCAPE_':lambda:window.close(),
	#'MOUSE_M':'set_cursor_lock',
	'MOUSE_M': lambda:window.set_cursor_lock(True),
	'A': lambda:print('hohox'),
	'A_': lambda:print('0000000000'),
}

def draw():
	1#print('h')
window.bind_draw(draw)

window.bind_keymap(keymap)

window.run()
