#from world import world
#world = World()

from window import Window
window = Window()
window.set_title('moving_rect_by_vao_update')


def camup(x=0,y=0,z=0):
	cx,cy,cz = cam.eye
	cam.eye = (x+cx,y+cy,z+cz)

keymap = {
	'ESCAPE_':lambda:window.close(),
	#'MOUSE_M':'set_cursor_lock',
	'MOUSE_M': lambda:window.set_cursor_lock(True),
	'T': lambda:print('hohox'),
	'T_': lambda:print('0000000000'),

	'Q':lambda:world.create(),
	
	'W':lambda:camup(z=-1),
	'S':lambda:camup(z=1),
	'A':lambda:camup(x=-1),
	'D':lambda:camup(x=1),
	'E':lambda:camup(y=1),
	'C':lambda:camup(y=-1),

}



from shader import Shader

vertn = """
#version 410 core
layout (location = 0) in vec3 position;
layout (location = 1) in vec3 color;
out vec3 out_color;

uniform mat4 Model;
//uniform mat4 View;
//uniform mat4 Projection;
uniform mat4 ProjectionView;

void main() 
{
    //gl_Position = ViewProjection * Model * vec4(pos, 1);
    
    //gl_Position = vec4(position, 1);
    //gl_Position = Projection * View * Model * vec4(position, 1);
    gl_Position = ProjectionView * Model * vec4(position, 1);
    out_color = vec3(1,0,1);
}

"""

shader = Shader(vertn)
shader.bind()

print(shader.get_loc_attribute('position'))
print(shader.get_loc_attribute('color'))
print(shader.get_loc_uniform('Model'))


#Model = ( 0.995004, 0.0998334, 0,0,     -0.0998334, 0.995004, 0,0,  0,0,1,0,    0.2, 0.2, 0,1 )
from matrix import Matrix
#Model = Matrix.Model( (0,-10,-10), (0,0,0,1),  (5,5,5) )
from quaternion import *
Model = Matrix.Model( (0,-10,-10), quat_from_aa(1,(1,1,1) ),  (5,5,5) )
shader.set_mat4('Model', Model.to_list() )



import glm

View = glm.lookAt( glm.vec3(1,3,4),glm.vec3(0,0,0), glm.vec3(0,1,0))
#View = ( 0.97, -0.14, 0.19, 0,   0, 0.80, 0.58, 0,  -0.24, -0.57, 0.78, 0 ,   -0, -0, -5.09, 1 )
#shader.set_mat4('View', View.to_list())

Projection = glm.perspective( 1, 1.96,0.1,200)
#Projection = (1.40, 0.0, 0.0, 0.0,   0.0, 2.74, 0.0, 0.0,   0.0, 0.0, -1.0, -1.0,   0.0, 0.0, -0.2, 0.0)
#print( glm.perspective(radians(57), 1.96,0.1,200).to_list() )
#shader.set_mat4('Projection', Projection.to_list())

#shader.set_mat4('ProjectionView', (Projection*View).to_list() )
print((Projection*View).to_list())

from camera import Camera
cam = Camera()
cam.fov = 57.295
cam.ratio = 1.96
cam.near = 0.1
cam.far = 200
cam.eye = (1,3,4)

ProjectionView = cam.get_ProjectionView()
shader.set_mat4('ProjectionView', (ProjectionView).to_list() )
print((ProjectionView).to_list(),'from Matrix')


#m = glm.lookAt( glm.vec3(1,3,4),glm.vec3(0,0,0), glm.vec3(0,1,0))
#print(m.to_list())
#m = cam.get_View()
#print(m.to_list())


#glm-camera is same!


rule = """
1. flatten.col.major(down first)  [1000, 0100, 0010, xyz1]

2. RH rotation, CCW.  0.1rad 
R = ( 0.995004, 0.0998334, 0,0,     -0.0998334, 0.995004, 0,0,  0,0,1,0,    0, 0, 0,1 )

3. mul: right to left
Model = T*R*S
Projection * View * Model * position

[ tx]   [vx]
[ ty] * [vy]
[ tz]   [vz]
[  1]   [ 1]

4. yup RH coords. z is not depth.

"""



from vao import Vao

data = {'position':[0,0,0,   1,0,0, 1,1,1 ,0,1,0] ,'index':[0,1,2, 0,2,3] ,'color': [1,0,0, 0,1,0, 0,0,1, 1,0,1] }
vao = Vao(data)


import numpy as np
arr = np.array( [0,0,0,   1,0,0, 1,1,1 ,0,1,0] ,dtype='float32')

def update(dt):
	global arr
	arr -= dt # dt*hz = 1seconds. so the rect hidden after 2 seconds.
	if arr[0]<-1:
		arr+=dt
	
	shader.set_mat4('ProjectionView', (cam.get_ProjectionView()).to_list() )
	vao.update('position',arr)
window.bind_update(update)

def draw():
	1#world.draw()
	vao.bind()
	vao.draw(3)
window.bind_draw(draw)

window.bind_keymap(keymap)

window.glPointSize(5)

window.run()
