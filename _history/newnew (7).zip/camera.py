from math import cos,sin,radians, sqrt

from matrix import Matrix

class Camera:
    def __init__(self):
        self.fov = 60
        self.ratio = 1.66
        self.near = 0.01
        self.far = 1000

        self.eye = (0,0,1)
        self.center = (0,0,0)
        self.up = (0,1,0)
        #self.front

        self.sensitivity = 1.0
        self.yaw = radians(90)
        self.pitch = 0.0

    def get_ProjectionView(self):
        Projection = self.get_Projection()
        View = self.get_View()
        ProjectionView = Projection * View
        return ProjectionView

    def get_Projection(self):
        return Matrix.Perspective( radians(self.fov), self.ratio,self.near,self.far)
    def get_Ortho(self):
        return Matrix.Ortho(self.left, self.right, self.bottom, self.top, self.near, self.far)
    def get_View(self):
        return Matrix.View(self.eye, self.center, self.up)


    def set_dxdy(self, dx,dy):
        "dx,dy range -1~1. y+up."
        yaw = self.yaw
        pitch = self.pitch
        mag = self.sensitivity
        yaw -= dx * mag
        pitch -= dy * mag

        r89 = radians(89)
        if pitch > r89:
            pitch = r89
        elif pitch < -r89:
            pitch = -r89

        vx = cos(yaw) * cos(pitch)
        vy = sin(pitch)
        vz = -sin(yaw) * cos(pitch)
        
        norm = sqrt(vx**2 + vy**2 + vz**2)
        direction = (vx/norm,vy/norm,vz/norm)
        
        self.front = direction
        self.yaw = yaw
        self.pitch = pitch

    def move(self, speed):
        vx,vy,vz = self.front
        px,py,pz = self.position
        self.position = px+vx*speed, py+vy*speed, pz+vz*speed
